package com.product.earthquakes.view;

import android.app.Fragment;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.product.earthquakes.R;
import com.product.earthquakes.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if(getSupportFragmentManager().findFragmentByTag("fragment") == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new MainFragment(), "fragment")
                    .commit();
        }
    }
}
