package com.product.earthquakes.model;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MainApiResponse {
    @GET("earthquakesJSON")
    Call<ResponseBody> getData(@Query(value = "formatted") String formatted,
                               @Query(value = "north")   String north,
                               @Query(value = "south")   String south,
                               @Query(value = "east") String east,
                               @Query(value = "west") String west,
                               @Query(value = "username") String username);
}
