package com.product.earthquakes.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class MainModel {
    @SerializedName("earthquakes")
    private ArrayList<EarthQuakeData> earthquakes;

    public ArrayList<EarthQuakeData> getEarthquakes() {
        return earthquakes;
    }

    public void setEarthquakes(ArrayList<EarthQuakeData> earthquakes) {
        this.earthquakes = earthquakes;
    }
}
