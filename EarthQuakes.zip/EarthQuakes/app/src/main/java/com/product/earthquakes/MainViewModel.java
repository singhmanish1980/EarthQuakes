package com.product.earthquakes;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.product.earthquakes.model.EarthQuakeData;
import com.product.earthquakes.model.MainModel;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

@Singleton
public class MainViewModel extends ViewModel {
    @Inject
    MainRepository mainRepository;

    MainModel serverData = null;
    public MutableLiveData<ArrayList<EarthQuakeData>> earthQuakeList = new MutableLiveData<>();

    public MainViewModel() {
        MainInjector.INSTANCE.getComponent().inject(this);
    }

    public MutableLiveData<ArrayList<EarthQuakeData>> getEarthQuakeList() {
        return earthQuakeList;
    }

    public void fetchDataFromServer() {

        // Simple Observable
        if (serverData == null) {
            mainRepository.fetchServerData().observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new SingleObserver<MainModel>() {
                        @Override
                        public void onSubscribe(Disposable d) {

                        }

                        @Override
                        public void onSuccess(MainModel mainResponseModels) {
                            serverData = mainResponseModels;
                            earthQuakeList.setValue(mainResponseModels.getEarthquakes());
                        }

                        @Override
                        public void onError(Throwable e) {

                        }
                    });
        } else {
            earthQuakeList.setValue(serverData.getEarthquakes());
        }
    }
}
