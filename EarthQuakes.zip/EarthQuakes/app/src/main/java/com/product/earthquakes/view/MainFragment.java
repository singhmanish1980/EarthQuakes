package com.product.earthquakes.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.product.earthquakes.MainViewModel;
import com.product.earthquakes.adapters.EarthQuakeAdapter;
import com.product.earthquakes.databinding.MainFragmentBinding;
import com.product.earthquakes.model.EarthQuakeData;

import androidx.lifecycle.Observer;

import java.util.ArrayList;

public class MainFragment extends Fragment {
    private static final String TAG = "MainFragment";
    private MainFragmentBinding binding;
    private MainViewModel viewModel;
    private EarthQuakeAdapter adapter;
    private ProgressDialog loading;
    private ArrayList<EarthQuakeData> dataList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = MainFragmentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if(viewModel == null) {
            viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        }

        initRecyclerView();
        observeData();
        if(loading == null) {
            loading = new ProgressDialog(getContext());
            loading.setCancelable(true);
            loading.setMessage("Loading..");
            loading.show();
        }
        viewModel.fetchDataFromServer();
    }

    @VisibleForTesting
    public MainViewModel getViewModel() {
        return viewModel;
    }


    private void observeData() {
        viewModel.getEarthQuakeList().observe(getViewLifecycleOwner(), new Observer<ArrayList<EarthQuakeData>>() {
            @Override
            public void onChanged(ArrayList<EarthQuakeData> data) {
                adapter.updateList(data);
                dataList = data;
                loading.dismiss();
            }
        });
    }

    private void initRecyclerView() {
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new EarthQuakeAdapter(getContext(), null);
        binding.recyclerView.setAdapter(adapter);
        binding.recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    View childView = rv.findChildViewUnder(e.getX(), e.getY());
                    if (childView != null) {
                        int index = rv.getChildLayoutPosition(childView);
                        showOnMap(index);
                    }
                }
                return true;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    private void showOnMap(int position) {
        if(position < 0) {
            return;
        }
        float lat = Float.parseFloat(dataList.get(position).getLat());
        float lng = Float.parseFloat(dataList.get(position).getLng());
        Intent intent = new Intent(getActivity(), MapActivity.class);
        intent.putExtra("latPosition",lat);
        intent.putExtra("lngPosition",lng);
        startActivity(intent);
    }
}
