package com.product.earthquakes.model;

import com.google.gson.annotations.SerializedName;

public class EarthQuakeData {
    @SerializedName("datetime")
    private String datetime;
    @SerializedName("depth")
    private String depth;
    @SerializedName("lng")
    private String lng;
    @SerializedName("src")
    private String src;
    @SerializedName("eqid")
    private String eqid;
    @SerializedName("magnitude")
    private String magnitude;
    @SerializedName("lat")
    private String lat;

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getDepth() {
        return depth;
    }

    public void setDepth(String depth) {
        this.depth = depth;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getEqid() {
        return eqid;
    }

    public void setEqid(String eqid) {
        this.eqid = eqid;
    }

    public String getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(String magnitude) {
        this.magnitude = magnitude;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }
}
