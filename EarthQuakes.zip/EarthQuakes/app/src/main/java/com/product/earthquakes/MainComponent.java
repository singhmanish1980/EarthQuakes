package com.product.earthquakes;

import dagger.Component;

@Component(modules = MainModule.class)
public interface MainComponent {
    MainRepository getMainRepository();
    void inject(MainViewModel viewmodel);
}
