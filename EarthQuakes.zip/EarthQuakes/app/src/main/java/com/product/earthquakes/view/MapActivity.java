package com.product.earthquakes.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.product.earthquakes.R;
import com.product.earthquakes.databinding.ActivityMainBinding;

public class MapActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if(getSupportFragmentManager().findFragmentByTag("fragment1") == null) {
            float lat = getIntent().getExtras().getFloat("latPosition");
            float lng = getIntent().getExtras().getFloat("lngPosition");
            MainMapFragment fragment = new MainMapFragment();
            fragment.setLat(lat);
            fragment.setLng(lng);
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,fragment, "fragment1")
                    .commit();
        }
    }
}
