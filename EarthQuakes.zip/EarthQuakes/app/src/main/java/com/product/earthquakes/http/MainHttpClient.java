package com.product.earthquakes.http;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import retrofit2.converter.gson.GsonConverterFactory;

public class MainHttpClient {
    private static Retrofit retrofitClient = null;

    /**
     * Method to get the Retrofit rest client object to make the HTTP Calls
     */
    public static Retrofit getRestClient(String url) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        OkHttpClient okHttpClient = httpClient.build();

        if (retrofitClient == null) {
            retrofitClient = new Retrofit.Builder()
                    .baseUrl(url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(okHttpClient)
                    .build();
        }

        return retrofitClient;
    }
}
