package com.product.earthquakes;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MainService extends Service {

    Handler handler =  new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
        }
    };

    public Handler getHandler(){
        return handler;
    }
    public IBinder binder = new MyLocalBinder();

    public class MyLocalBinder extends Binder {
        public MainService getService(){
            return MainService.this;
        }
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}
