package com.product.earthquakes;

import dagger.Module;
import dagger.Provides;

@Module
public class MainModule {

    @Provides
    MainRepository provideRepository(){
        return new MainRepository();
    }

}
