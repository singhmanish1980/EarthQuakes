package com.product.earthquakes.view;

public class MainConstants {
    public static final String BASE_URL = "http://api.geonames.org/";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String ACCEPT = "Accept";
    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String NO_STORE ="no-store";

}