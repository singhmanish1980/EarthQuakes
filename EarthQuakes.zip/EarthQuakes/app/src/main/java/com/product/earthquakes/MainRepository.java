package com.product.earthquakes;

import com.google.gson.Gson;
import com.product.earthquakes.http.MainHttpClient;
import com.product.earthquakes.model.MainApiResponse;
import com.product.earthquakes.model.MainModel;
import com.product.earthquakes.view.MainConstants;

import java.io.IOException;

import io.reactivex.Single;
import io.reactivex.SingleEmitter;
import io.reactivex.SingleOnSubscribe;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainRepository {
    public Single<MainModel> fetchServerData() {

        return Single.create(new SingleOnSubscribe<MainModel>() {
            @Override
            public void subscribe(final SingleEmitter<MainModel> emitter) throws Exception {
                final Call<ResponseBody> call = MainHttpClient.getRestClient(MainConstants.BASE_URL)
                        .create(MainApiResponse.class).getData("true", "44.1", "-9.9", "-22.4", "55.2",
                                "mkoppelman");
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        try {
                            String responseString = response.body().string();
                            MainModel model = new Gson().fromJson(responseString, MainModel.class);
                            emitter.onSuccess(model);
                        } catch (IOException io) {
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        emitter.onError(null);
                    }
                });
            }
        });

    }
}
