package com.product.earthquakes.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.product.earthquakes.databinding.ListItemBinding;
import com.product.earthquakes.model.EarthQuakeData;

import java.util.ArrayList;

/**
 * Adapter, to display list
 */
public class EarthQuakeAdapter extends RecyclerView.Adapter<EarthQuakeAdapter.EarthQuakeViewHolder> {
    private Context mContext;
    private ArrayList<EarthQuakeData> mList;
    private ListItemBinding binding;

    public EarthQuakeAdapter(Context mContext, ArrayList<EarthQuakeData> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @NonNull
    @Override
    public EarthQuakeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        binding = ListItemBinding.inflate(inflater,parent,false);
        return new EarthQuakeViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EarthQuakeViewHolder holder, int position) {
        holder.itemBinding.eqid.setText("Eqid: " + mList.get(position).getEqid());
        holder.itemBinding.id1.setText("Date: " + mList.get(position).getDatetime());
        if(Float.parseFloat(mList.get(position).getMagnitude()) >= 8) {
            holder.itemBinding.eqid.setTextColor(Color.RED);
            holder.itemBinding.id1.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }

    class EarthQuakeViewHolder extends RecyclerView.ViewHolder{
        private ListItemBinding itemBinding;

        public EarthQuakeViewHolder(ListItemBinding itemBinding) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
        }
    }

    public  void updateList(ArrayList<EarthQuakeData> updatedList){
        mList = updatedList;
        notifyDataSetChanged();
    }

    public  EarthQuakeData getEarthQuakeDataAt(int position){
        return mList.get(position);
    }
}
